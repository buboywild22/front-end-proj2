import React from 'react';
import Navbar from './Navb2';
import Footer from './Footer'
const Notfound = () => {
    return (
        <div>
        <Navbar/>
            <h1>Page Not Found!</h1>
            <Footer/>
        </div>
        
    );
}

export default Notfound;
